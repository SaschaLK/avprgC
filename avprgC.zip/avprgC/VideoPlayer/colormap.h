#ifndef COLORMAP_H
#define COLORMAP_H
#include "videoprocessor.h"

class ColorMap : public VideoProcessor
{
public:
    ColorMap();
    void startProcessing(const VideoFormat& format);
    cv::Mat process(const cv::Mat& input);
    void setThreshold(int value);
private:
    int value;
};

#endif // COLORMAP_H
